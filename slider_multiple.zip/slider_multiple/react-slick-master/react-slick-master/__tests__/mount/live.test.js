import { getJQuerySlickDetails } from "../jQSlickUtils";
import { getReactSlickDetails } from "../reactSlickUtils";

describe("live testing module", () => {
  let settings = {
    infinite: true,
    speed: 0,
    useCSS: false,
    noOfSlides: 5,
    slidesToShow: 3,
    slidesToScroll: 1
    // centerMode: true,
  };
  let actions = {
    clickNext: 0,
    clickPrev: 0,
    clickSequence: []
  };
  let keys = {
    // currentSlide: true,
    // activeSlides: true,
    clonedSlides: true
    // allSlides: true,
  };
  let reactDetails = getReactSlickDetails(settings, actions, keys);
  let jqueryDetails = getJQuerySlickDetails(settings, actions, keys);

  test("fake test", () => {
    expect(1).toBe(1);
  });
}); 
